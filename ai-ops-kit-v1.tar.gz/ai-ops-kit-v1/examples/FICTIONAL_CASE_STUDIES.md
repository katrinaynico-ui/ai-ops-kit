# Fictional case studies — MARKETING EXAMPLES ONLY
**[FICTION / SAMPLE]** These companies, people, and metrics are invented for illustrating the product.
**Do NOT** copy them into a real CV, LinkedIn, proposal, or application as personal experience.

## Sample A — “Northpine Supplies” (invented SMB)
- Problem: leads stuck in inbox
- Kit used: Intake → Sheet template + alert SOP
- Illustrative result: “same-day triage” narrative for sales page
- Tag every screenshot: DEMO / SAMPLE

## Sample B — “Cascadia Clinics Ops” (invented)
- Problem: messy CRM tags
- Kit used: CRM hygiene checklist
- Illustrative result: “one pipeline view in 7 days” narrative

## Sample C — “Harbor Creative Co” (invented)
- Problem: inconsistent social templates
- Kit used: creative ops pack outline
- Illustrative result: “2 weeks of posts batched”

## Disclaimer (required on sales page)
> Examples are fictional illustrations of how the templates can be used. They are not client results.
