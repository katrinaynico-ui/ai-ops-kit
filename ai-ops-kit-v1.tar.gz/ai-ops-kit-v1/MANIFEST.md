# Pack manifest — 2026-09-20T23:31:05+02:00

- `README.md` · 1058B · sha256:81963d81a3cc0b80
- `demos/crm_hygiene_sample/index.html` · 1852B · sha256:65ba8723e1e9a941
- `demos/intake_sample/README.md` · 83B · sha256:de4aa70456fd6ef3
- `demos/intake_sample/index.html` · 4287B · sha256:e40f2223dc4bd9b9
- `examples/FICTIONAL_CASE_STUDIES.md` · 1009B · sha256:cccb12985408fa8b
- `sales/STORE_LISTING_DRAFT.md` · 4251B · sha256:40931c816709d9cd
- `sales/index.html` · 3105B · sha256:f087a542707fe06d
- `sales/landing.md` · 682B · sha256:5c201aa93d8f55b1
- `sales/one_pager.html` · 2898B · sha256:b5037fd3baff30f8
- `sops/DELIVER_IN_7_DAYS.md` · 271B · sha256:995a37c4f9ff807f
- `templates/crm_hygiene_checklist.md` · 316B · sha256:08156410d604cde7
- `templates/intake_field_map.md` · 348B · sha256:c10d169de25944c2
