# CRM hygiene checklist (template)
Use in HubSpot / Sheet. Mark only work you actually do.

- [ ] Dedupe by email
- [ ] Normalize lifecycle
- [ ] Archive stale deals
- [ ] Assign owners
- [ ] Source tags
- [ ] Disable broken automations
- [ ] Weekly pipeline view

No client logos. No invented before/after metrics.
