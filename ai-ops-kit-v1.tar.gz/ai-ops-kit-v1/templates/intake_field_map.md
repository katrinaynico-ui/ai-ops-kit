# Intake field map (template)
| Field | Type | Required | Notes |
|-------|------|----------|-------|
| ts | datetime | yes | auto |
| name | string | yes | |
| company | string | yes | |
| email | email | yes | |
| pain | text | yes | |
| budget | enum | no | ≤500 / 500-1500 / 1500+ / unknown |
| status | enum | yes | NEW / TRIAGED / CLOSED |
