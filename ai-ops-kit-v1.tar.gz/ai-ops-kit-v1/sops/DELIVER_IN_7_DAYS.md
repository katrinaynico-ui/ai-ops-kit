# SOP — Deliver Intake Automation in 7 days
1. Day 1: confirm fields + alert destination
2. Day 2-3: form + sheet/CSV
3. Day 4: alert text + test row
4. Day 5: SOP for client
5. Day 6: QA
6. Day 7: handoff call/async notes
Never claim prior client logos without proof.
