# AI Ops Kit v1.1 — Intake → Sheet → Alert + CRM hygiene
Digital product / portfolio asset for Income OS.

## Pricing [ESTIMADO]
- **€79** — digital kit (this pack)
- **€349** — done-with-you install (upsell, sold separately)

## What's inside
- `demos/intake_sample/` — browser DEMO (no backend) **[SAMPLE]**
- `demos/crm_hygiene_sample/` — CRM hygiene checklist DEMO **[SAMPLE]**
- `templates/` — field maps + CRM hygiene checklist
- `sops/` — 7-day delivery SOP
- `examples/FICTIONAL_CASE_STUDIES.md` — **FICTION only**
- `sales/` — landing, ES sales page, one-pager, store listing draft

## Honest claims only
- This kit was built as a SAMPLE automation demo.
- No fabricated client logos, testimonials, or revenue.
- Fiction examples are labeled **FICTION / SAMPLE**.

## Demos
- [Intake SAMPLE](demos/intake_sample/index.html)
- [CRM hygiene SAMPLE](demos/crm_hygiene_sample/index.html)

## Sales
- [ES sales page](sales/index.html)
- [EN one-pager](sales/one_pager.html)
- [Store listing draft](sales/STORE_LISTING_DRAFT.md)
