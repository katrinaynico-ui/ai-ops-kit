# AI Ops Kit v1.1 — Intake + CRM hygiene
Turn messy inbound messages into a clean row + alert — plus a 7-check CRM hygiene sprint.

## Includes
- Browser SAMPLE demos you can click (intake + CRM hygiene)
- Field map + CRM checklist templates
- 7-day delivery SOP
- Example stories clearly marked **FICTION / SAMPLE**

## Price [ESTIMADO]
**€79** digital kit · **€349** done-with-you install

## Not included
Fake testimonials. Fake case studies presented as real. Job-application lies. Live hosting or CRM licenses.

## CTA
Buy the €79 kit → open both SAMPLE demos → follow the 7-day SOP.  
Need it installed? Ask for the €349 done-with-you install **[ESTIMADO]**.
