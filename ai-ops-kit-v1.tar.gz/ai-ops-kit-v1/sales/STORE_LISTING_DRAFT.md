# Store listing — AI Ops Kit v1.1 (paste-ready)
Updated: 2026-09-20T23:31:05+02:00 (Europe/Zurich)
Status: LOCAL READY · distribution blocked (no payout rail / repo write) [VERIFICADO]
Prices: **€79** digital kit · **€349** done-with-you install — both **[ESTIMADO]**

---

## Title
AI Ops Kit v1.1 — Inbox Intake + CRM Hygiene (Templates + SAMPLE Demos)

## Short description (≤160 chars / store blurb)
Turn messy inbound leads into a clean sheet row + alert, plus a 7-check CRM hygiene sprint. Templates, clickable SAMPLE demos, 7-day SOP. Fiction labeled FICTION.

## Long description (paste into Gumroad / Lemon Squeezy)

**AI Ops Kit v1.1** is a practical digital pack for solo founders and tiny SMBs who lose leads in the inbox and run a messy CRM.

You get ready-to-adapt templates, a 7-day delivery SOP, and two **clickable SAMPLE demos** that run 100% in the browser (no backend, no account). Use them to learn the flow, demo to a client, or adapt into Zapier / Make / n8n / Sheets.

### What you get
- **Intake SAMPLE demo** — form → normalized table row → alert text + CSV export (browser-only)
- **CRM hygiene SAMPLE demo** — 7-check sprint checklist with progress
- **Templates** — intake field map + CRM hygiene checklist (markdown)
- **SOP** — deliver an intake→sheet setup in 7 days
- **Sales assets** — landing copy, one-pager, ES sales page (adapt freely)
- **FICTION examples** — clearly labeled fictional case narratives for illustration only

### Who it's for
- Solo founders / freelancers drowning in inbox leads
- Tiny SMBs with HubSpot / Sheets / Notion CRM chaos
- Operators who want a honest SAMPLE pack to adapt — not fake “case study” marketing

### What's NOT included
- Live hosting, Zapier/Make accounts, or CRM licenses
- Custom coding, ongoing support, or guaranteed results
- Real client testimonials or verified revenue claims
- Job-application “experience” you can paste as your own

### Requirements
- Modern browser to open the SAMPLE demos
- Optional: Google Sheets / HubSpot / Zapier / Make / n8n if you want to go live
- Basic willingness to map fields to your own tools

### Pricing [ESTIMADO]
| Offer | Price | What |
|-------|-------|------|
| Digital kit (this product) | **€79** | Download pack + demos + templates + SOP |
| Done-with-you install (upsell) | **€349** | Guided install of intake→sheet + hygiene pass (sold separately / custom) |

### Honesty tags
- Demos and case narratives: **[FICTION SAMPLE]**
- Prices: **[ESTIMADO]** until a live store listing confirms them
- No fabricated clients, logos, or revenue **[VERIFICADO policy]**

### FAQ
**1. Is this a live SaaS?**  
No. It’s a downloadable kit with in-browser SAMPLE demos. You adapt the templates to your stack.

**2. Are the case studies real clients?**  
No. Examples are marked **FICTION / SAMPLE**. They illustrate how the templates can be used — not results you achieved for paying clients.

**3. Will this connect to my HubSpot / Sheets automatically?**  
Not out of the box. The demos simulate the flow. The SOP and field map help you wire Zapier/Make/n8n yourself — or book the €349 install upsell.

**4. What’s the difference between €79 and €349?**  
€79 = files + demos + SOP. €349 = done-with-you guided install (separate engagement; not included in the digital download).

**5. Refunds?**  
Set your store policy (recommended: 7–14 day digital refund if files unopened / unused). This draft does not invent a policy for you.

### CTA
**Buy the €79 kit** → download → open `demos/intake_sample/index.html` and `demos/crm_hygiene_sample/index.html` → follow `sops/DELIVER_IN_7_DAYS.md`.  
Want it installed for you? Ask about the **€349 done-with-you** install **[ESTIMADO]**.

---

## Bullet list (store “What’s included” field)
- Intake → table → alert SAMPLE demo (+ CSV export)
- CRM hygiene 7-check SAMPLE demo
- Intake field map + CRM hygiene checklist templates
- 7-day delivery SOP
- Sales landing / one-pager / ES page to adapt
- FICTION-labeled example narratives (not client results)

## Tags / keywords (optional)
ai ops, crm hygiene, lead intake, google sheets, zapier, make.com, n8n, smb automation, templates, sample demo
